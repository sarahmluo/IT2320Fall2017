﻿namespace FinalProject.Models
{
    public class AddOrUpdateElementRequestModel
    {
        public string Username { get; set; }
        public string ElementName { get; set; }
        public string ElementValue { get; set; }
    }
}